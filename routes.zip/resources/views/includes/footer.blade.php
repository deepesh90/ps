<div class="footer" >

    <div>
        <strong>Copyright</strong> P3 &copy; 2015-2016
    </div>
</div>