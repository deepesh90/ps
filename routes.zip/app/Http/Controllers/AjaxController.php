<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Customer;
use App\model\employee;

class AjaxController extends Controller
{
    //
	public function __construct()
	{
		$this->middleware('auth');
	}
	public function search_customer(Request $request)
	{
		$input=$request->input();
		 $data=Customer::where('customer_name','LIKE',"%$input[term]%")->limit(10)->get();
		 
		$result=[];
		$i=0;
		foreach ($data as $arr){
			$result[$i]['label']=$arr->customer_name;
			$result[$i]['value']=$arr->customer_name;
			$result[$i]['id']=$arr->id;
			$i++;
		}
		
		echo json_encode($result);exit;
	}
	public function search_manager(Request $request)
	{
		$input=$request->input();
		 $data=employee::leftJoin('departments', 'departments.id', '=', 'employee.department_id')->
		 where('name','LIKE',"%$input[term]%")-> where('department_name','LIKE',"Project Manager")->select('employee.*')->limit(10)->get();
		 
		$result=[];
		$i=0;
		foreach ($data as $arr){
			$result[$i]['label']=$arr->name;
			$result[$i]['value']=$arr->name;
			$result[$i]['id']=$arr->id;
			$i++;
		}
		
		echo json_encode($result);exit;
	}
	
}
