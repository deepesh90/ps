<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    //
  public $table='currencys';
	    public $timestamps=false;
}
