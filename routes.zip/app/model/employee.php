<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class employee extends Model
{
    //
    public $table='employee';
	    public $timestamps=false;
}
