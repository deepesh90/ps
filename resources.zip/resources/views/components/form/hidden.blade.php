 {{ Form::hidden($name, $value, array_merge(['class' => 'form-control','id'=>$name], $attributes)) }}
