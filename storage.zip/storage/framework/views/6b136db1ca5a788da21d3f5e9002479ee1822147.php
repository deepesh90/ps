<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    
    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/lc_switch.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('css/codemirror.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/custom.css')); ?>">
    
    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head>

<body>

<body class="fixed-sidebar">

<div id="wrapper">
<?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper" class="gray-bg">
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</div>
</div>

    <!-- Scripts -->
        <script src="<?php echo e(url('js/jquery-2.1.1.js')); ?>"></script>
    <script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/metisMenu/jquery.metisMenu.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo e(url('js/inspinia.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/pace/pace.min.js')); ?>"></script>

    <script src="<?php echo e(url('js/codemirror.js')); ?>"></script>
    <script src="<?php echo e(url('js/codescript.js')); ?>"></script>
</body>
</html>
