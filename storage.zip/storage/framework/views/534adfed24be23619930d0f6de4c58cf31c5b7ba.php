<?php $__env->startSection('content'); ?>
<div class="row wrapper border-bottom white-bg page-heading ng-scope">
  <div class="col-lg-10">
    <h2>User Type</h2>
  </div>
</div>

<div class="wrapper wrapper-content animated fadeIn ng-scope" ng-init="init()">
  <div class="row">
    <div class="col-md-12">
      <div class="ibox float-e-margins">
        <div class="ibox-title">
          <h5>User Type List</h5>
        </div>
        <div class="ibox-content">
          <table class="table table-bordered">
                <tbody>
                <tr>
                  <th style="width: 10px">#</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>User Type</th>
                  <th>Status</th>
                  <th style="width: 30%">Action</th>
                </tr>
                <?php (($i=0)); ?>
               <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                <tr>
                   <td><?php echo e(++$i); ?></td>
                   <td><?php echo e($arr->name); ?></td>
                   <td><?php echo e($arr->email); ?></td>
                   <td><?php echo e($arr->user_permission); ?></td>
                                      <td><?php echo e($arr->status); ?></td>
                                     
                  <td>
                  								                  										
															<a class="btn btn-xs btn-info" href="<?php echo e(url('user-type/edit/'.$arr->id)); ?>">
																<i class="ace-icon fa fa-pencil bigger-120"></i>
															</a>

															<a class="btn btn-xs btn-danger" onclick="return confirm('Are you sure you want to delete?')" href="<?php echo e(url('user-type/delete/'.$arr->id.'/usertype/user-type')); ?>">
																<i class="ace-icon fa fa-eye bigger-120"></i>
															</a>

															
                  </td>
                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
               </tbody></table>
        </div>
      </div>
    </div>
  </div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>