 <div class="form-group" id="<?php echo e($name); ?>_div">
 <?php echo e(Form::label($label, null,[])); ?>

 <?php echo e(Form::text($name, $value, array_merge(['class' => 'form-control','id'=>$name], $attributes))); ?>

 <span class="error" id="<?php echo e($name); ?>_error"><?php echo e($error); ?></span>
</div>