<?php $__env->startSection('content'); ?>
<div class="row wrapper border-bottom white-bg page-heading ng-scope">
  <div class="col-lg-10">
    <h2>User Type</h2>
  </div>
</div>

<div class="wrapper wrapper-content animated fadeIn ng-scope" ng-init="init()">
  <div class="row">
    <div class="col-md-12">
      <div class="ibox float-e-margins">
        <div class="ibox-title">
          <h5>New User Type</h5>
        </div>
        <div class="ibox-content">
                     <?php echo e(Form::open(array('url' => 'user-type/saveRole','method'=>'post'))); ?>

                                 <?php echo e(Form::inputHidden('record','',isset($result['id']) ? $result['id'] :'')); ?>

            				     <?php echo e(Form::inputText('name','User Type Name',isset($result['name']) ? $result['name'] :'','',['required'=>'true'])); ?>

                                 <?php echo e(Form::inputSelect('parent_id','Parent Role',$select_data,isset($result['parent_id']) ? $result['parent_id'] :'')); ?>

                                  <button type="submit" class="btn btn-primary">
                                    Save
                                </button>       
           			<?php echo e(Form::close()); ?>

        </div>
      </div>
    </div>
  </div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>