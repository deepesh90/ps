<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>P3 | Admin</title>

    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('css/lc_switch.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('css/codemirror.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/custom.css')); ?>">


</head>

<body class="fixed-sidebar">

        <?php echo $__env->yieldContent('content'); ?>
    <!-- Mainly scripts -->
    <script src="<?php echo e(url('js/jquery-2.1.1.js')); ?>"></script>
    <script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/metisMenu/jquery.metisMenu.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo e(url('js/inspinia.js')); ?>"></script>
    <script src="<?php echo e(url('js/plugins/pace/pace.min.js')); ?>"></script>

    <script src="<?php echo e(url('js/codemirror.js')); ?>"></script>
    <script src="<?php echo e(url('js/codescript.js')); ?>"></script>






</body>

</html>
