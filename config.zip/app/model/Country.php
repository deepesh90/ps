<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    //

	//
	public $table='countrys';
	public $timestamps=false;
	
}
