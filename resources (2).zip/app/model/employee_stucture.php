<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class employee_stucture extends Model
{
    //
    public $table='employee_stucture';
    public $timestamps=false;
}
