<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Userrole extends Model
{
    //
	protected $table = 'userrole';
	public  $timestamps =false;
	
}
