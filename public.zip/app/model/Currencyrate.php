<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Currencyrate extends Model
{
    //
	public $timestamps=false;
	
}

