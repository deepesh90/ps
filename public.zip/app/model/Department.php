<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    //
    public $timestamps=false;
}
